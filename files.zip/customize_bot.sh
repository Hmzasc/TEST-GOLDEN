#!/bin/bash

# 🎨 سكريبت تخصيص بوت واتساب تلقائياً
# يقوم باستبدال جميع معلومات "الملك صقر" بمعلوماتك الخاصة

echo "╭━━━━━━━━━━━━━━━━━━━━━━━━━━╮"
echo "│  🎨 أداة تخصيص البوت  │"
echo "╰━━━━━━━━━━━━━━━━━━━━━━━━━━╯"
echo ""

# اطلب المعلومات من المستخدم
read -p "📝 أدخل اسم البوت الجديد: " BOT_NAME
read -p "👤 أدخل اسمك (المطور): " DEVELOPER_NAME
read -p "📱 أدخل رقمك (بدون +): " PHONE_NUMBER
read -p "🔗 أدخل رابط قناتك: " CHANNEL_LINK
read -p "💻 أدخل اسم حسابك على GitHub: " GITHUB_USERNAME
read -p "📦 أدخل اسم حزمة الملصقات: " PACK_NAME
read -p "⚡ أدخل إيموجي البوت (افتراضي: 🔥): " BOT_EMOJI

# استخدم القيم الافتراضية إذا لم يتم إدخال شيء
BOT_EMOJI=${BOT_EMOJI:-"🔥"}

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📋 ملخص المعلومات:"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🤖 اسم البوت: $BOT_NAME"
echo "👨‍💻 المطور: $DEVELOPER_NAME"
echo "📱 الرقم: $PHONE_NUMBER"
echo "🔗 القناة: $CHANNEL_LINK"
echo "💻 GitHub: $GITHUB_USERNAME"
echo "📦 الحزمة: $PACK_NAME"
echo "⚡ الإيموجي: $BOT_EMOJI"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

read -p "✅ هل المعلومات صحيحة؟ (y/n): " CONFIRM

if [ "$CONFIRM" != "y" ] && [ "$CONFIRM" != "Y" ]; then
    echo "❌ تم الإلغاء. شغّل السكريبت مرة أخرى."
    exit 1
fi

echo ""
echo "🔄 جاري التخصيص..."
echo ""

# نسخ احتياطية
echo "📦 إنشاء نسخة احتياطية..."
cp settings.js settings.js.backup 2>/dev/null
cp index.js index.js.backup 2>/dev/null
cp main.js main.js.backup 2>/dev/null

# تعديل settings.js
if [ -f "settings.js" ]; then
    echo "✏️ تعديل settings.js..."
    sed -i "s/packname: '[^']*'/packname: '$PACK_NAME'/g" settings.js
    sed -i "s/author: '[^']*'/author: '$DEVELOPER_NAME'/g" settings.js
    sed -i "s/botName: \"[^\"]*\"/botName: \"$BOT_NAME\"/g" settings.js
    sed -i "s/botOwner: '[^']*'/botOwner: '$DEVELOPER_NAME'/g" settings.js
    sed -i "s/ownerNumber: '[^']*'/ownerNumber: '$PHONE_NUMBER'/g" settings.js
    echo "   ✅ تم تعديل settings.js"
fi

# تعديل index.js
if [ -f "index.js" ]; then
    echo "✏️ تعديل index.js..."
    sed -i "s/global.botname = \"[^\"]*\"/global.botname = \"$BOT_NAME\"/g" index.js
    sed -i "s/global.themeemoji = \"[^\"]*\"/global.themeemoji = \"$BOT_EMOJI\"/g" index.js
    sed -i "s/YT CHANNEL: [^\"\\n]*/YT CHANNEL: $DEVELOPER_NAME/g" index.js
    sed -i "s/GITHUB: [^\"\\n]*/GITHUB: $GITHUB_USERNAME/g" index.js
    sed -i "s/CREDIT: [^\"\\n]*/CREDIT: $DEVELOPER_NAME/g" index.js
    echo "   ✅ تم تعديل index.js"
fi

# تعديل main.js
if [ -f "main.js" ]; then
    echo "✏️ تعديل main.js..."
    sed -i "s|global.channelLink = \"[^\"]*\"|global.channelLink = \"$CHANNEL_LINK\"|g" main.js
    sed -i "s/global.ytch = \"[^\"]*\"/global.ytch = \"$DEVELOPER_NAME\"/g" main.js
    echo "   ✅ تم تعديل main.js"
fi

# تعديل data/owner.json
if [ -f "data/owner.json" ]; then
    echo "✏️ تعديل data/owner.json..."
    echo "[\"$PHONE_NUMBER\"]" > data/owner.json
    echo "   ✅ تم تعديل data/owner.json"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ اكتمل التخصيص بنجاح!"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "📋 الملفات المعدلة:"
echo "   ✅ settings.js"
echo "   ✅ index.js"
echo "   ✅ main.js"
echo "   ✅ data/owner.json"
echo ""
echo "💾 النسخ الاحتياطية محفوظة بامتداد .backup"
echo ""
echo "🚀 الخطوات التالية:"
echo "   1. أعد تشغيل البوت"
echo "   2. تحقق من الأوامر (.menu، .owner، .alive)"
echo "   3. احذف الأوامر غير المرغوبة من مجلد commands/"
echo ""
echo "╭━━━━━━━━━━━━━━━━━━━━━━━━━━╮"
echo "│   شكراً لاستخدام الأداة!   │"
echo "╰━━━━━━━━━━━━━━━━━━━━━━━━━━╯"
