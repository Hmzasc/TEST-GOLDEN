/**
 * Info Command - Display bot information
 * Compatible with King Saqr Bot
 * 
 * Usage: .info
 * Permission: Public
 */

const settings = require('../settings');

async function infoCommand(sock, chatId, message) {
    const channelInfo = {
        contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
        }
    };

    const botInfo = `
╭━━━━━━━━━━━━━━━━━━╮
│  🤖 *معلومات البوت*
╰━━━━━━━━━━━━━━━━━━╯

📌 *الاسم:* ${settings.botName}
👨‍💻 *المطور:* ${settings.botOwner}
📱 *الرقم:* ${settings.ownerNumber}
⚙️ *الإصدار:* ${settings.version}
🔧 *الوضع:* ${settings.commandMode}

━━━━━━━━━━━━━━━━━━

📊 *الإحصائيات:*
⏰ *وقت التشغيل:* ${getUptime()}
💾 *الذاكرة:* ${getMemoryUsage()}
📨 *الرسائل:* يعمل بشكل مستقر

━━━━━━━━━━━━━━━━━━

🔗 *الروابط المهمة:*
📢 القناة: https://t.me/+T_8QE67Pn6tkMzNk
💻 GitHub: github.com/mruniquehacker

╭━━━━━━━━━━━━━━━━━━╮
│ شكراً لاستخدام البوت! ❤️
╰━━━━━━━━━━━━━━━━━━╯
    `.trim();

    await sock.sendMessage(chatId, { 
        text: botInfo,
        ...channelInfo 
    }, { quoted: message });
}

// Helper function to get uptime
function getUptime() {
    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);
    return `${hours}س ${minutes}د ${seconds}ث`;
}

// Helper function to get memory usage
function getMemoryUsage() {
    const used = process.memoryUsage().heapUsed / 1024 / 1024;
    return `${Math.round(used)} ميجابايت`;
}

module.exports = infoCommand;
