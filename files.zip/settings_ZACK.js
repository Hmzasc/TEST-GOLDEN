const settings = {
  packname: '🥀 Z A C K Bot',           // اسم حزمة الملصقات
  author: 'Hamza Scorpion',             // اسم المؤلف
  botName: "Z A C K",                   // اسم البوت
  botOwner: 'حمزة سكوربيون',           // اسم المالك بالعربي
  ownerNumber: '22247608339',           // رقم البوت
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",                // الوضع العام
  maxStoreMessages: 20, 
  storeWriteInterval: 10000,
  description: "Z A C K - بوت واتساب متطور من تطوير حمزة سكوربيون",
  version: "1.0.0",                     // إصدار جديد
  updateZipUrl: "https://github.com/hamza-mbeih/zack-bot/archive/refs/heads/main.zip",
};

module.exports = settings;
